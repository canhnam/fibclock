# Fibonacci Clock — Phase 1 (renderer + app + color themes)

1. Unzip, then in Android Studio: File > Open > select the FibonacciClock folder.
2. Let Gradle sync (Android Studio will offer to create/download the Gradle wrapper; accept).
3. Run on a device/emulator (Android 8.0+).

Usage: tap "Settings" (top-right) to choose a preset or Custom colors. Settings persist (DataStore).

Layout:
- clock/FibonacciClockRenderer.kt  shared drawing code (will be reused by widget + wallpaper)
- clock/ClockTheme.kt              preset themes
- data/                            DataStore settings
- ui/                              Compose screens
