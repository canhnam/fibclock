package com.example.fibclock.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import com.example.fibclock.clock.FibonacciClockRenderer
import com.example.fibclock.data.ClockSettings
import kotlinx.coroutines.delay

@Composable
fun ClockScreen(settings: ClockSettings, onOpenSettings: () -> Unit) {
    val renderer = remember { FibonacciClockRenderer() }
    val theme = settings.toTheme()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(settings.showSeconds) {
        while (true) {
            if (settings.showSeconds) {
                withFrameMillis { now = System.currentTimeMillis() }   // smooth second hand
            } else {
                now = System.currentTimeMillis()
                delay(1000L - now % 1000L)                              // save battery
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color(theme.background))) {
        Canvas(Modifier.fillMaxSize()) {
            val t = now // read here so only the canvas redraws
            drawIntoCanvas { c ->
                renderer.draw(c.nativeCanvas, size.width, size.height, theme, t, settings.showSeconds)
            }
        }
        TextButton(
            onClick = onOpenSettings,
            modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding(),
        ) {
            Text("Settings", color = Color(theme.accent).copy(alpha = 0.8f))
        }
    }
}
