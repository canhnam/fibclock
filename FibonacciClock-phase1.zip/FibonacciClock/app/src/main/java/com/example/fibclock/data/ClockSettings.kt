package com.example.fibclock.data

import com.example.fibclock.clock.ClockTheme
import com.example.fibclock.clock.Themes

data class ClockSettings(
    val themeId: String = Themes.BlackGold.id,
    val customBg: Int = Themes.BlackGold.background,
    val customFg: Int = Themes.BlackGold.foreground,
    val customAccent: Int = Themes.BlackGold.accent,
    val showSeconds: Boolean = true,
) {
    fun toTheme(): ClockTheme =
        if (themeId == "custom") ClockTheme("custom", "Custom", customBg, customFg, customAccent)
        else Themes.byId(themeId) ?: Themes.BlackGold
}
