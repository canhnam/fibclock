package com.example.fibclock.clock

import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import androidx.core.graphics.ColorUtils
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.atan2

/**
 * Draws the Fibonacci clock on a plain android.graphics.Canvas so the same code
 * can be reused by the app, the home-screen widget and the live wallpaper.
 *
 * Geometry is built in a unit space: golden rectangle of width 1 and height PHI.
 * Time is read clockwise from 12 o'clock around the spiral's pole (its "eye").
 */
class FibonacciClockRenderer {

    private val phi = (1.0 + sqrt(5.0)) / 2.0
    private val poleX = (phi - 1.0) / (2.0 * phi - 1.0)
    private val poleY = phi - phi * poleX

    private class Sq(val x: Double, val y: Double, val s: Double)

    private val squares = ArrayList<Sq>()
    private val spX: DoubleArray
    private val spY: DoubleArray
    private val spR: DoubleArray   // distance from pole
    private val spT: DoubleArray   // unwrapped clockwise angle (deg) from 12 o'clock

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.SERIF
    }

    init {
        val xs = ArrayList<Double>()
        val ys = ArrayList<Double>()
        var x = 0.0; var y = 0.0; var w = 1.0; var h = phi
        val arcSteps = 32
        for (i in 0 until 20) {
            val cx: Double; val cy: Double; val side: Double; val a0: Double
            when (i % 4) {
                0 -> { side = w; squares.add(Sq(x, y, side)); cx = x; cy = y + side; a0 = -90.0; y += side; h -= side }
                1 -> { side = h; squares.add(Sq(x + w - side, y, side)); cx = x + w - side; cy = y; a0 = 0.0; w -= side }
                2 -> { side = w; squares.add(Sq(x, y + h - side, side)); cx = x + w; cy = y + h - side; a0 = 90.0; h -= side }
                else -> { side = h; squares.add(Sq(x, y, side)); cx = x + side; cy = y + side; a0 = 180.0; x += side; w -= side }
            }
            for (k in (if (i == 0) 0 else 1)..arcSteps) {
                val a = Math.toRadians(a0 + 90.0 * k / arcSteps)
                xs.add(cx + side * cos(a))
                ys.add(cy + side * sin(a))
            }
        }
        val n = xs.size
        val r = DoubleArray(n); val t = DoubleArray(n)
        var prev = 0.0
        for (i in 0 until n) {
            val dx = xs[i] - poleX
            val dy = ys[i] - poleY
            r[i] = hypot(dx, dy)
            var a = Math.toDegrees(atan2(dx, -dy))
            if (i > 0) while (a < prev) a += 360.0
            t[i] = a; prev = a
        }
        spX = xs.toDoubleArray(); spY = ys.toDoubleArray(); spR = r; spT = t
    }

    /** Distance from the pole to the spiral along the ray at [thetaDeg] (clockwise from 12). */
    private fun radiusAt(thetaDeg: Double): Double {
        val t = ((thetaDeg % 360.0) + 360.0) % 360.0
        var lo = 0; var hi = spT.size - 1
        while (hi - lo > 1) {
            val mid = (lo + hi) / 2
            if (spT[mid] <= t) lo = mid else hi = mid
        }
        val f = ((t - spT[lo]) / (spT[hi] - spT[lo])).coerceIn(0.0, 1.0)
        return exp(ln(spR[lo]) * (1 - f) + ln(spR[hi]) * f)
    }

    private fun alpha(color: Int, a: Int) = (color and 0x00FFFFFF) or (a shl 24)

    fun draw(canvas: Canvas, width: Float, height: Float, theme: ClockTheme, timeMillis: Long, showSeconds: Boolean) {
        val bg = theme.background; val fg = theme.foreground; val ac = theme.accent
        canvas.drawColor(bg)

        val margin = 0.04 * min(width, height)
        val sc = min((width - 2 * margin), (height - 2 * margin) / phi)
        val ox = (width - sc) / 2.0
        val oy = (height - sc * phi) / 2.0
        fun px(v: Double) = (ox + v * sc).toFloat()
        fun py(v: Double) = (oy + v * sc).toFloat()
        fun ptX(r: Double, deg: Double) = poleX + r * sin(Math.toRadians(deg))
        fun ptY(r: Double, deg: Double) = poleY - r * cos(Math.toRadians(deg))
        val s = sc.toFloat()

        // Soft face inside the spiral
        val face = Path().apply {
            moveTo(px(poleX), py(poleY))
            var d = 0
            while (d <= 360) {
                val r = radiusAt(d.toDouble()) * 0.87
                lineTo(px(ptX(r, d.toDouble())), py(ptY(r, d.toDouble())))
                d += 2
            }
            close()
        }
        paint.style = Paint.Style.FILL
        paint.color = ColorUtils.blendARGB(bg, ac, 0.07f)
        canvas.drawPath(face, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = s * 0.0012f
        paint.color = alpha(fg, 70)
        canvas.drawPath(face, paint)

        // Accent tint on the inner squares
        paint.style = Paint.Style.FILL
        paint.color = alpha(ac, 30)
        for (i in 2 until squares.size) {
            val q = squares[i]
            canvas.drawRect(px(q.x), py(q.y), px(q.x + q.s), py(q.y + q.s), paint)
        }

        // Golden rectangle + squares
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = s * 0.0012f
        paint.color = alpha(fg, 150)
        canvas.drawRect(px(0.0), py(0.0), px(1.0), py(phi), paint)
        for (q in squares) canvas.drawRect(px(q.x), py(q.y), px(q.x + q.s), py(q.y + q.s), paint)

        // Dashed diagonals (they cross at the pole)
        paint.color = alpha(fg, 80)
        paint.pathEffect = DashPathEffect(floatArrayOf(s * 0.012f, s * 0.012f), 0f)
        canvas.drawLine(px(0.0), py(phi), px(1.0), py(0.0), paint)
        canvas.drawLine(px(0.0), py(1.0), px(1.0), py(phi), paint)
        paint.pathEffect = null

        // Spiral
        val spiral = Path()
        for (i in spX.indices) {
            if (i == 0) spiral.moveTo(px(spX[i]), py(spY[i])) else spiral.lineTo(px(spX[i]), py(spY[i]))
        }
        paint.color = fg
        paint.strokeWidth = s * 0.003f
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        canvas.drawPath(spiral, paint)

        // Minute dots
        paint.style = Paint.Style.FILL
        paint.color = fg
        for (m in 0 until 60) {
            val th = m * 6.0
            val r = radiusAt(th) * 0.93
            val dot = r * (if (m % 5 == 0) 0.012 else 0.005) * sc
            canvas.drawCircle(px(ptX(r, th)), py(ptY(r, th)), dot.toFloat(), paint)
        }

        // Hour numbers
        textPaint.color = fg
        for (hr in 1..12) {
            val th = (hr % 12) * 30.0
            val r = radiusAt(th) * 0.8
            textPaint.textSize = (r * 0.125 * sc).toFloat().coerceAtLeast(4f)
            val fm = textPaint.fontMetrics
            canvas.drawText(hr.toString(), px(ptX(r, th)), py(ptY(r, th)) - (fm.ascent + fm.descent) / 2f, textPaint)
        }

        // Hands
        val cal = Calendar.getInstance().apply { timeInMillis = timeMillis }
        val sec = cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000.0
        val min = cal.get(Calendar.MINUTE) + sec / 60.0
        val hour = (cal.get(Calendar.HOUR) % 12) + min / 60.0
        val cxp = px(poleX); val cyp = py(poleY)

        fun hand(deg: Double, factor: Double): Pair<Float, Float> {
            val r = radiusAt(deg) * factor
            return px(ptX(r, deg)) to py(ptY(r, deg))
        }

        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND

        val (hx, hy) = hand(hour * 30.0, 0.46)
        paint.color = fg; paint.strokeWidth = s * 0.016f
        canvas.drawLine(cxp, cyp, hx, hy, paint)
        paint.color = bg; paint.strokeWidth = s * 0.009f
        canvas.drawLine(cxp, cyp, hx, hy, paint)

        val (mx, my) = hand(min * 6.0, 0.58)
        paint.color = fg; paint.strokeWidth = s * 0.007f
        canvas.drawLine(cxp, cyp, mx, my, paint)

        if (showSeconds) {
            val (sx, sy) = hand(sec * 6.0, 0.85)
            paint.color = ac; paint.strokeWidth = s * 0.0035f
            canvas.drawLine(cxp, cyp, sx, sy, paint)
        }

        // Hub
        paint.style = Paint.Style.FILL
        paint.color = ac
        canvas.drawCircle(cxp, cyp, s * 0.017f, paint)
        paint.color = bg
        canvas.drawCircle(cxp, cyp, s * 0.007f, paint)
    }
}
