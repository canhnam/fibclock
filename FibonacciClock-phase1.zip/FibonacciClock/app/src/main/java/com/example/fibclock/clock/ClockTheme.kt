package com.example.fibclock.clock

data class ClockTheme(
    val id: String,
    val name: String,
    val background: Int,
    val foreground: Int,
    val accent: Int,
)

object Themes {
    val BlackGold = ClockTheme("black_gold", "Black & Gold", 0xFF0E0E0F.toInt(), 0xFFF0EAE0.toInt(), 0xFFD9A441.toInt())
    val Navy = ClockTheme("navy", "Navy", 0xFF0B1426.toInt(), 0xFFE8EEF8.toInt(), 0xFF5BC0EB.toInt())
    val Paper = ClockTheme("paper", "Paper", 0xFFF4F1EA.toInt(), 0xFF1B1B1B.toInt(), 0xFFB5462F.toInt())
    val Forest = ClockTheme("forest", "Forest", 0xFF0F1A14.toInt(), 0xFFE6EFE6.toInt(), 0xFF8FD694.toInt())
    val Mono = ClockTheme("mono", "Mono", 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF9E9E9E.toInt())

    val presets = listOf(BlackGold, Navy, Paper, Forest, Mono)
    fun byId(id: String): ClockTheme? = presets.firstOrNull { it.id == id }
}
