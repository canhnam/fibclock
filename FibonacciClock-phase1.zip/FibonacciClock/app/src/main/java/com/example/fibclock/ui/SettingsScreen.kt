package com.example.fibclock.ui

import android.graphics.Color as AColor
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.dp
import com.example.fibclock.clock.FibonacciClockRenderer
import com.example.fibclock.clock.Themes
import com.example.fibclock.data.ClockSettings

@Composable
fun SettingsScreen(
    settings: ClockSettings,
    onChange: ((ClockSettings) -> ClockSettings) -> Unit,
    onClose: () -> Unit,
) {
    val renderer = remember { FibonacciClockRenderer() }
    val previewTime = remember { System.currentTimeMillis() }
    val theme = settings.toTheme()

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.statusBarsPadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Settings", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
                TextButton(onClick = onClose) { Text("Done") }
            }

            Canvas(Modifier.fillMaxWidth().height(300.dp).clip(MaterialTheme.shapes.medium)) {
                drawIntoCanvas { c ->
                    renderer.draw(c.nativeCanvas, size.width, size.height, theme, previewTime, true)
                }
            }

            Text("Color theme", style = MaterialTheme.typography.titleMedium)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Themes.presets.forEach { p ->
                    Swatch(p.name, p.background, p.accent, settings.themeId == p.id) {
                        onChange { it.copy(themeId = p.id) }
                    }
                }
                Swatch("Custom", settings.customBg, settings.customAccent, settings.themeId == "custom") {
                    onChange { s ->
                        val t = s.toTheme()
                        s.copy(themeId = "custom", customBg = t.background, customFg = t.foreground, customAccent = t.accent)
                    }
                }
            }

            if (settings.themeId == "custom") {
                ColorPickerRow("Background", settings.customBg) { c -> onChange { it.copy(customBg = c) } }
                ColorPickerRow("Hands & numbers", settings.customFg) { c -> onChange { it.copy(customFg = c) } }
                ColorPickerRow("Accent", settings.customAccent) { c -> onChange { it.copy(customAccent = c) } }
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Show second hand", Modifier.weight(1f))
                Switch(checked = settings.showSeconds, onCheckedChange = { v -> onChange { it.copy(showSeconds = v) } })
            }
        }
    }
}

@Composable
private fun Swatch(name: String, bg: Int, accent: Int, selected: Boolean, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(56.dp).clip(CircleShape).background(Color(bg))
                .border(if (selected) 3.dp else 1.dp, if (selected) Color(accent) else Color.Gray, CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(18.dp).clip(CircleShape).background(Color(accent)))
        }
        Spacer(Modifier.height(4.dp))
        Text(name, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun ColorPickerRow(label: String, color: Int, onColor: (Int) -> Unit) {
    val init = remember { FloatArray(3).also { AColor.colorToHSV(color, it) } }
    var h by remember { mutableFloatStateOf(init[0]) }
    var s by remember { mutableFloatStateOf(init[1]) }
    var v by remember { mutableFloatStateOf(init[2]) }
    fun push() = onColor(AColor.HSVToColor(floatArrayOf(h, s, v)))

    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(24.dp).clip(CircleShape).background(Color(color)).border(1.dp, Color.Gray, CircleShape))
            Spacer(Modifier.width(10.dp))
            Text(label)
        }
        Slider(value = h, onValueChange = { h = it; push() }, valueRange = 0f..360f)
        Slider(value = s, onValueChange = { s = it; push() }, valueRange = 0f..1f)
        Slider(value = v, onValueChange = { v = it; push() }, valueRange = 0f..1f)
    }
}
