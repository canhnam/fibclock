package com.example.fibclock.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore("clock_settings")

/** Single source of truth. The widget and wallpaper (later phases) will read this too. */
class SettingsRepository(private val context: Context) {

    private object K {
        val themeId = stringPreferencesKey("theme_id")
        val bg = intPreferencesKey("custom_bg")
        val fg = intPreferencesKey("custom_fg")
        val accent = intPreferencesKey("custom_accent")
        val seconds = booleanPreferencesKey("show_seconds")
    }

    private fun read(p: Preferences): ClockSettings {
        val d = ClockSettings()
        return ClockSettings(
            themeId = p[K.themeId] ?: d.themeId,
            customBg = p[K.bg] ?: d.customBg,
            customFg = p[K.fg] ?: d.customFg,
            customAccent = p[K.accent] ?: d.customAccent,
            showSeconds = p[K.seconds] ?: d.showSeconds,
        )
    }

    val settings: Flow<ClockSettings> = context.dataStore.data.map { read(it) }

    suspend fun update(transform: (ClockSettings) -> ClockSettings) {
        context.dataStore.edit { p ->
            val n = transform(read(p))
            p[K.themeId] = n.themeId
            p[K.bg] = n.customBg
            p[K.fg] = n.customFg
            p[K.accent] = n.customAccent
            p[K.seconds] = n.showSeconds
        }
    }
}
