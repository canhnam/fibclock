package com.example.fibclock

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.fibclock.data.ClockSettings
import com.example.fibclock.data.SettingsRepository
import com.example.fibclock.ui.ClockScreen
import com.example.fibclock.ui.SettingsScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        val repo = SettingsRepository(applicationContext)
        setContent { FibClockApp(repo) }
    }
}

@Composable
fun FibClockApp(repo: SettingsRepository) {
    val settings by repo.settings.collectAsState(initial = ClockSettings())
    val scope = rememberCoroutineScope()
    var showSettings by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        if (showSettings) {
            BackHandler { showSettings = false }
            SettingsScreen(
                settings = settings,
                onChange = { transform -> scope.launch { repo.update(transform) } },
                onClose = { showSettings = false },
            )
        } else {
            ClockScreen(settings = settings, onOpenSettings = { showSettings = true })
        }
    }
}
